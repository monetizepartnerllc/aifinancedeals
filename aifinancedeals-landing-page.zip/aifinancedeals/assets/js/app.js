
const options = document.querySelectorAll('.quiz-option');

options.forEach(option => {
  option.addEventListener('click', () => {
    alert('Quiz completed! Redirect your /go page to Monetag Smartlink.');
  });
});
