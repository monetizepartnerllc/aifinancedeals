<?php
header("Location: https://your-monetag-smartlink.com");
exit();
?>